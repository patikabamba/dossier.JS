// Liste des journaux
let journaux = ["http://lemonde.fr", "http://lefigaro.fr", "http://liberation.fr", "http://sudouest.fr"];

// TODO : ajouter la liste des journaux sur la page, dans la div "contenu"
